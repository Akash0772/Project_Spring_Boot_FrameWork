package com.akash.datajpa4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpa4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
